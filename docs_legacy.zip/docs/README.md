# Project documentation

Documentation lives in this folder so the repository root stays focused on the application source. The top-level [`README.md`](../README.md) remains in place for GitHub's project overview.

**Current project version:** 1.1.1 (development branch).

- [Changelog](CHANGELOG.md) — development history and release notes.

## Testing and verification guides

- [Dynamic theme icons for browser favicon and Qt/KDE launcher](TESTING_DYNAMIC_THEME_ICONS.md)

- [Live Crossbar Router and mixer-matrix source names](TESTING_GLOBAL_ROUTER_LABELS.md)

- [Crossbar Router changes update the source labels beneath faders](TESTING_ROUTER_FADER_LABELS.md)

- [Saffire PRO 40 native 1394 and Mic/Lin/Inst input labels](TESTING_INPUT_LABELS.md)

- [Saffire PRO 40: linked input pan, paired output buses and compact labels](TESTING_PRO40_STEREO_PAN.md)

- [Adaptive bus selector: two columns for small mixers, extra columns for ProFire-style devices](TESTING_ADAPTIVE_BUS_GRID.md)
- [Priority 2: arbitrary input stereo pairs and safe routing (v1.1.1 development build)](TESTING_ARBITRARY_STEREO.md)
- [Testing source-defined device capabilities (v1.1.1 development build)](TESTING_CAPABILITIES.md)
- [v1.1.1 development build — Matrix gain precision testing](TESTING_GAIN_PRECISION.md)
- [Initial stereo pan display — Priority 3](TESTING_INITIAL_PAN.md)
- [v1.1.1 development build — inline matrix-cell rotary controls](TESTING_MATRIX_CELL_ROTARY.md)
- [Matrix → strip synchronization (v1.1.1 development build)](TESTING_MATRIX_STRIP_SYNC.md)
- [MOTU UltraLite (first generation) bus-routing update](TESTING_MOTU_ULTRALITE.md)
- [Three interfaces + KDE Plasma: v1.1.1 development build validation](TESTING_MULTIPLE_DEVICES_KDE.md)
- [Peak-metering test and diagnostic report (v1.1.1 development build)](TESTING_PEAK_METERS.md)
- [Shared live meter stream and responsiveness (v1.1.1-dev)](TESTING_SMOOTH_LIVE_METERS.md)
- [About QR view / v1.0.1 quick test](TESTING_QR.md)
- [Saffire PRO 26 — hardware testing and bug-report guide (ffado-webmixer 1.0.1)](TESTING_SAFFIRE_PRO26.md)
- [Testing the QjackCtl and About settings update](TESTING_SETTINGS.md)
- [v1.1.1 development build — Software mute/solo resilience and recovery](TESTING_SOFTWARE_MUTE_SOLO.md)
- [Regression: input stereo pairs must be independent per bus](TESTING_STEREO_BUS_VISIBILITY.md)
- [Stereo pairing validation (Priority 4)](TESTING_STEREO_PAIR_VALIDATION.md)
- [ffado-webmixer 1.1.1 development build — hardware and debug testing](TESTING_V1_1.md)
- [Priority 7 — mixer Volume vs. hardware Input Gain](TESTING_VOLUME_TERMINOLOGY.md)

## Other documentation

## Package, profile, and theme documentation

- [Python package layout and data ownership](PYTHON_PACKAGE.md)
- [FFADO device profile overview](PROFILES.md)
- [Exact model resolution and architecture](PROFILE_ARCHITECTURE.md)
- [Source-derived model capabilities](PROFILE_CAPABILITIES.md)
- [Device profile definitions](DEVICE_PROFILES.md)
- [Custom user themes](USER_THEMES.md)
- [Built-in theme assets](THEME_ASSETS.md)

The implementation files, XML device profiles, and theme assets remain under [`src/ffado_webmixer/`](../src/ffado_webmixer/); their Markdown documentation is kept here.

For new testing guides, add them here and link them from this index instead of putting more Markdown files in the project root.
