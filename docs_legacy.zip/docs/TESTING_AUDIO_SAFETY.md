# Audio safety patch — regression verification

This patch is limited to the three audio-safety fixes: delayed fader writes, DICE
Crossbar Router rollback, and generic stereo-pair write rollback. It does not
change FFADO matrix gain conversion or stereo routing mathematics.

## Automated checks (no device required)

Run from the repository root:

```sh
python -m pytest -q tests/test_audio_safety.py tests/test_router_strip_labels.py
node tests/audio_safety_ui_test.cjs
```

To run the full suites:

```sh
python -m pytest -q
for test in tests/*_test.cjs; do node "$test" || break; done
```

`test_audio_safety.py` simulates D-Bus operations that return false, throw before
writing, throw after a successful hardware change, and report incorrect readback.
It tests restoration to an existing source or to a muted destination. It also
simulates second-leg failures in demo and source-profile MOTU/DICE matrix mixers,
including a write that modifies the hardware then raises an exception.

`audio_safety_ui_test.cjs` checks that rapid fader changes are coalesced in order
and carry the bus and device GUID associated with the original strip, even after
a different bus or device becomes selected.

## On-device verification (requires physical hardware)

**Reduce power-amplifier and headphone monitoring levels before testing.** Tests
which intentionally alter routing may interrupt audio, even with rollback.

1. **MOTU UltraLite mk1, or any multibus mixer:** Select Bus 1. Move a fader
   quickly and immediately select Bus 2. Verify Bus 1 received the final fader
   change and Bus 2's corresponding fader did not move unexpectedly. Repeat on
   a phone browser, with slower network conditions if possible.
2. **Linked MOTU channels:** Link two channels in a bus and move the shared
   fader. Verify that *both* underlying channels move and return correct values
   after refresh. Do not simulate live hardware failures by physically unplugging
   FireWire cables.
3. **Saffire PRO 40 / ProFire with DICE Crossbar Router:** Change one mixer
   input between valid sources and between a source and Disconnected. Verify the
   displayed input name matches a fresh hardware readback. On a normal successful
   operation, unrelated destinations must remain unchanged.
4. **Multi-device tabs:** If multiple FFADO devices are connected, switch between
   them during/after a quick series of fader changes and verify no write reaches
   an unintended device.

## Limitations

FFADO Crossbar Router transactions are not atomic at the device-protocol level.
Rollback is best-effort and readback-verified. If restoration cannot be
confirmed, the API reports `rollback may be incomplete`; inspect the hardware
routing before resuming live audio. Similar best-effort rollback is used for
generic linked-channel writes; a later successful retry does not erase an
earlier warning about incomplete restoration.
