# Backend reliability regression checklist (v1.1.1-dev)

This patch builds **on the audio-safety update**. It changes settings/layout
validation and transaction handling, and server startup behavior. It does **not**
change FFADO routing algorithms, matrix gain calculations, network binding
(`0.0.0.0:5000`), authentication, or packaging.

## Automated offline tests

From the project root:

```bash
PYTHONPATH=. pytest -q
for test in tests/*.cjs; do node "$test" || exit 1; done
```

`tests/test_backend_reliability.py` covers malformed JSON *shapes* (objects,
arrays and null), booleans and numeric types, settings writes to both device and
global startup config, persistence failures (including a simulated failure
*after* a disk write), layout preservation, and bounded startup failures.
Malformed JSON syntax itself is rejected by Flask's standard HTTP 400 parser.

The offline suite uses lightweight Flask, Qt and Werkzeug test doubles in some
tests. Actual Flask HTTP operation requires Flask to be installed and an
end-to-end check on the user's system. No FireWire hardware is accessed by these
tests.

## Desktop and browser checks

1. Back up `~/.config/ffado-webmixer/` and start the server as usual.
2. Open Settings -> General. Toggle **Enable QjackCtl** and **Hide minimized**;
   restart and verify they persisted. Switch themes and accent overrides,
   restart, and verify the Qt splash uses the saved global theme.
3. With two browsers viewing the same physical device, reorder/minimize strips.
   Changes should remain isolated to the relevant bus. Switching away and back
   should preserve channels that were hidden when a layout was saved.
4. Set a harmless device alias. Restart; the alias should remain associated
   with the device GUID. QjackCtl Graph and Patchbay should still work when
   enabled.
5. Use an API client to POST a non-object payload to `/api/settings`, a
   non-list payload to `/api/layout?mix=0`, or a duplicate channel id in a
   layout. Expect HTTP **400**. No setting/layout should change or be saved.
6. Occupy TCP port 5000 with a different process, then launch
   `python main.py --demo`. Expect an immediate, clear port-binding error,
   **not** a Qt splash that waits forever. Stop the other listener and start
   the application normally.

## Error and persistence semantics

- Validation happens before the first config mutation.
- Writes acquire the relevant per-device and global configuration locks.
- JSON file replacement is atomic *per file*. The two separate JSON files
  cannot be committed atomically as a single disk operation: on a failure,
  the server tries to restore both prior snapshots. If rollback cannot
  complete, the HTTP 500 response explicitly warns about incomplete rollback.
  An OS crash/power loss between two files is not solved by this patch.
- The Qt client verifies the listener has started before opening its window.
  A listener that dies after startup is reported rather than leaving an
  unbounded loading loop.
