# Bus drag and Minimize / Maximize verification

This patch is frontend-only. It does not change FFADO's audio routing, gain,
software mute, or stereo-link implementation.

## Desktop browser / native window

1. Open a device with nine or more buses. All newly discovered bus tabs start
   pinned; the left drag dots are hidden. Existing unpin choices remain saved.
2. Open Bus 5's three-dot **actions menu** and select **Unpin**. Only Bus 5's
   left drag grip should appear, with a **grab** cursor on hover. Bus 6 should
   remain pinned without a visible grip.
3. Drag the Bus 5 grip to the left of Bus 1. Bus 5 should move on its own;
   Bus 6 should stay in its original position. Release the pointer, then
   reload the page and confirm the order is saved.
4. Pin Bus 5 again. The left grip should disappear while the bus name stays
   centered. Unpin it again to confirm the handle reappears.
5. Link Bus 1+2 via the actions menu. The linked pair should appear as one
   tab. Unpin and drag it: the two bus indices move together. Unlink and
   verify they once again have independent drag handles and positions.
6. Minimize any bus and any channel fader. Their actions menus should display
   **Maximize** (not Restore). Selecting Maximize must unminimize the control.
7. Test on a phone or tablet as well: unpin a tab, drag its left grip, and
   confirm its order persists. The grip must not cause the name input to edit.

## Automated checks

Run the full Python regression suite and JS tests from the project root:

```bash
python -m pytest -q
for file in tests/*test.cjs; do node "$file" || exit 1; done
```

A headless Chromium interaction check additionally verified the independent
Bus 5 reorder, backend save, renderer refresh, paired tab, hidden pin grip,
grab cursor, and menu labels against a mocked 18-bus device.

**Physical-device verification:** UI changes were checked with a simulated
Saffire PRO 40. Test bus-tab ordering on the actual interface; the real FFADO
routing and gain operations are deliberately not exercised by this test.
