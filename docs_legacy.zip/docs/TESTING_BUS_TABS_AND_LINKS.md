# Bus tabs and overlapping link buttons (v1.1.1-dev)

## What changed

- When FFADO reports **nine or more buses**, the bus picker moves from the
  sidebar to a horizontally scrollable tab bar above the channel strips.
  Devices with **eight or fewer buses** retain their existing sidebar controls.
- Every bus has an editable name (Enter saves, Escape cancels), a pin/unpin
  button, and a minimize/restore button. The grip at the beginning of each
  unpinned tab reorders its tile by drag and drop. Layout persists for each
  physical device GUID in `bus_layout` alongside the existing device config.
- **Hide minimized buses** in Settings > General removes minimized bus tabs,
  except the currently selected bus (and linked right leg). Minimized buses
  remain in the saved layout and can be restored by unchecking the setting.
- FFADO only supports adjacent even/odd stereo bus pairing in this interface.
  The chain icon placed at the seam of each two-bus tile invokes the existing
  `/api/bus-stereo` route. Linked pairs remain adjacent in the UI and move as
  a unit; individual buses keep separate name, pin, and minimize settings.
- Channel stereo link/unlink buttons were moved from the bottom-right corner
  of fader strips to the **top-right overlapping edge**, like the reference UI.
  The existing click-Left, click-Right linking order remains unchanged.
- There are no changes to gain/dB calculations, audio routing, meter sampling,
  or the hardware operations performed by the original stereo link API.

## Automated checks

```
PYTHONPATH=src pytest -q
node tests/bus_tabs_ui_test.cjs
for test in tests/*_test.cjs; do node "$test"; done
```

The backend tests exercise persisted order, invalid JSON, rejected and
partially failed writes, the checkbox setting, and aliases for buses without
independent output controls. A browser smoke test with mock endpoints checked
an 18-bus tab bar, active state, rename, pin, minimize, hide, and drag reorder.

## Real-device verification (monitor level down)

1. Open the webmixer with a Saffire PRO 40 / ProFire 2626 (more than eight
   buses). Confirm buses appear as tabs across the top and Main/Phones remain
   in the right-hand output area. Verify a small-bus MOTU uses the sidebar.
2. Select different bus tabs. Confirm that the channel faders and pan refer to
   the selected bus, and that Main/Phones controls behave as before.
3. Rename a bus, pin another, drag an **unpinned** bus pair, and minimize a
   third. Refresh the browser and restart the app; verify these choices persist.
4. Enable **Hide minimized buses** and check that hidden tabs are skipped, but
   the active selection remains visible. Disable it and restore minimized tabs.
5. Link an even/odd bus pair with the overlapping chain icon, inspect the
   linked-pan behavior on a known low-level signal, and unlink it. Confirm
   that link/unlink does not change routing unexpectedly. Other bus pairs must
   remain unchanged.
6. Link any two unpaired input faders (first click chooses Left, second Right),
   then unlink via the overlapping control. Repeat with non-adjacent channels.
7. Confirm a failed network save shows a warning and reverts to server state
   rather than leaving a layout that cannot survive reload.
8. Open two browser tabs connected to the same device. Reorder a bus tile and
   verify the other tab eventually refreshes without switching its selected bus.
9. Check touch scrolling of bus tabs and dragging in a phone/tablet browser,
   including the extreme left/right ends of a long bus list.

The automated tests do not guarantee real FFADO hardware behavior or Qt/KDE
presentation. In particular, the native even/odd bus-link semantics must be
verified on the relevant DICE/RME device before live use.
