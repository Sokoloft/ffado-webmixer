# Compact bus tabs and deliberate text editing

Applies to the PyPI-ready `src/` distribution. There are no new backend gain,
router, or stereo-pair semantics in this update.

## Bus tab checks (Saffire PRO 40 / 9+ buses)

1. Verify bus tabs are compact and horizontally scrollable. Click a label to
   select the bus without entering edit mode. Check browser widths near 400 px
   and 1300 px.
2. Open the **⋮** menu at the right end of a tab. Use **Pin**, **Unpin**,
   **Minimize**, and **Restore**. A pinned tab should darken slightly in each
   theme, not acquire a bright border. Verify state persists after restarting.
3. For minimized tabs, the numeric bus ID and menu should remain visible.
   **Rename** in the menu should restore the tab and open its text editor.
4. Drag an **unpinned** tab using its narrow grip and verify the order persists.
   Pinned tabs and linked even/odd bus groups retain their existing drag rules.
5. Verify the adjacent bus stereo link/unlink control still functions (keep
   monitoring levels reduced for hardware tests). A linked bus pair stays together.
6. Enable **Hide minimized buses**. Nonactive minimized tabs should disappear,
   while the selected one remains visible. Re-enable visibility and restore tabs.

## Editable text fields

- Channel names, bus names, output/master names, digital fader dB/value boxes,
  hardware input gain, and ordinary text/number fields in settings and the
  matrix editor should remain read-only on a normal click.
- **Right-click** a field on desktop or **long-press** it for about 550 ms on a
  phone or tablet. The field becomes editable. **F2** is the keyboard alternative.
- **Enter** applies changes according to each field's existing behavior; for
  fader values, **Escape** or leaving the box cancels. On leaving an editor, a
  regular click should no longer change its value.
- Dragging/scrolling across a textbox on a touchscreen must cancel the
  long-press gesture. Normal fader, pan, and router slider gestures must work.
- Check Firefox and QtWebEngine on KDE as well as Chromium; these tests were
  exercised in headless Chromium without a real FFADO device.

## Automated checks

Run `PYTHONPATH=src pytest -q` and `node tests/compact_bus_tabs_ui_test.cjs`,
then the remaining `tests/*_test.cjs` scripts. On physical hardware, verify
no spurious FFADO writes occur while merely selecting a bus.
