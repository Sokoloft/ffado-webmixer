# Crossbar Router compact destination labels

Development version: **1.1.1**. Physical Saffire PRO 40 validation is pending.

## Expected display

The Crossbar Router uses user-facing group headings and destination labels, without changing the underlying FFADO identifiers.

| Original FFADO group | Group heading | Example raw destination | Displayed destination |
| --- | --- | --- | --- |
| `1394/Out` | Firewire | `1394/Out:01` | Firewire 1 |
| `ADAT/Out` | ADAT | `ADAT/Out:01` | ADAT 1 |
| `Line/Out` | Line Out | `Line/Out:01` | Line Out 1 |
| `Loop` | Loop | `Loop:01` | Loop 1 |
| `Mixer/In` | Mixer Inputs | `Mixer/In:09` with `Mute:00` source | In 9 ← Disconnected |

Row numbers omit redundant leading zeroes. Other recognized FFADO labels retain their compact display names; unknown/custom labels are not changed.

## Hardware verification

1. On the Saffire PRO 40, open **In / Out → Crossbar Router**.
2. Confirm the group headings match the above table and the destination rows show **Firewire 1**, **Line Out 1**, **Loop 1**, etc.
3. Confirm the selected source in each dropdown remains the same as before this UI change. **Do not change routes unnecessarily**, especially while monitoring speakers.
4. If you choose a different source deliberately at low volume, confirm it changes the intended *original FFADO destination*, for example `Line/Out:01`, not another destination.
5. Verify the peak meters still display at their original hardware destinations, and **Mixer matrix** input headings still use the currently selected router source.

The browser regression covers all five groups and checks raw meter destination keys, source dropdown values, actual POST destination identifiers, and display text. It does not substitute for a physical hardware test.
