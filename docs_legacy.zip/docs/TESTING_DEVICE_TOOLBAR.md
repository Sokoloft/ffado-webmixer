# Multi-device chooser and toolbar — manual verification

This UI change does not modify FFADO audio controls or routing. Run the app with reduced monitoring levels when testing against physical hardware.

1. **Two devices connected.** With the Saffire PRO 40 and MOTU UltraLite detected, confirm a new interface-switcher button appears immediately after Hardware Routing. Open it and verify both interfaces appear, with a check on the current one. Choose the other interface. The page should reload and show the newly selected device's channels; saved settings and bus layouts should remain isolated by GUID.
2. **One device connected.** The interface-switcher button should disappear. Hardware Routing, Settings, and browser Fullscreen remain available as supported. A native pywebview window intentionally hides browser Fullscreen.
3. **Error handling.** If switching is rejected by the server, the current mixer must remain active, an error must appear, and the switcher must be usable again. Do not deliberately unplug a bus-powered FireWire device to simulate this.
4. **Menu input.** Click or tap outside the dropdown to close it. Press Escape to close it and return keyboard focus to the selector. Arrow Up/Down, Home, End, and Enter must work with the dropdown items. Long names should fit without overflowing the screen.
5. **Toolbar.** With two, three, or four buttons visible, all icon targets should be equally sized, with an even highlight inset on each side when hovered. Check on desktop KDE Plasma and in a mobile-width browser; narrow sidebars may wrap the buttons, but none should clip.
6. **Routing regression.** Open Hardware Routing and verify its existing functionality remains unchanged after switching between devices.

Offline coverage: `tests/device_selector_toolbar_ui_test.cjs` and the headless Chromium smoke test used during development verify visibility, menu actions, error handling, and equal button geometry. These tests cannot substitute for a physical two-device session on Linux.
