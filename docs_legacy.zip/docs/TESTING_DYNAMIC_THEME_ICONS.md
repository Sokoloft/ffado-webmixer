# Dynamic theme icons — v1.1.1 development

The splash's mixer bars now supply colors for the browser favicon and the
pywebview Qt window icon. The bar and slider colors match the active theme's
`--pin-color`, `--accent-color`, `--fader-value-color`, and `--text-primary`.
The tile uses `--sidebar-background`. A six-digit accent override recolors the
pin and accent bars, as it does on the intro screen.

## Browser

1. Open the mixer and change **Settings → Theme** from Dark to Light, then to
   Gruvbox. The tab favicon should immediately change colors.
2. Set a custom hex accent, then Reset. The two accent-colored bars should
   track the override and revert to the theme defaults when reset.
3. Refresh, close/reopen and check that saved theme and accent are applied.
4. A browser-only instance (`python main.py --headless`) should still serve
   `/favicon.svg?theme=gruvbox&accent=%23bb77aa` without importing Qt.
5. Check a user theme under `~/.config/ffado-webmixer/themes/` if installed.
   Its defined CSS colors should be used for the icon.

## KDE Plasma / pywebview

1. Start `python main.py` through the Qt6 pywebview backend. The window and
   intro favicon should use the configured theme when the app starts.
2. Change Theme and Accent in the native application. The live window icon
   should change via a queued Qt GUI-thread signal, without reopening it.
3. If you installed the per-user launcher using
   `python packaging/desktop_integration.py`, its hicolor SVG is also kept in
   sync as the theme changes. Only this program's matching desktop entry and
   icon are modified, never system-wide desktop files.
4. **Wayland/KDE caveat:** Plasma may use a cached icon from the pinned
   `.desktop` launcher instead of Qt's updated window icon. Relaunch the app,
   or unpin and repin if necessary, to see its new cached launcher artwork.
5. Test with **Skip loading screen** enabled and disabled.

All icon changes are visual; no hardware mixer state or D-Bus control changes.
