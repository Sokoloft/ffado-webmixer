# Editable fader volume / unity reset (v1.1.1-dev)

The channel-strip and master-output volume boxes are now editable inputs.
For DICE/RME profiles with an advertised native dB scale, click the box,
type `+3.1 dB`, `3.1`, `-10.0`, or `0.0` and press **Enter** to submit.
**Escape** or leaving the field without Enter discards the entry. Invalid
values are rejected rather than silently clamped; use `−∞` to set silence.

- Rounded displayed values close to zero are shown as `0.0 dB` with no `+` or `-`.
- Double-click the channel fader handle or its track to restore **0.0 dB (unity)**, not silence.
- The same interaction works on the master/output fader after the selected output has loaded.
- Hardware without a declared native dB scale continues showing/editing its existing
  0–100 values. The UI does **not** claim to know its 0 dB position.
- A read-only channel cannot submit edits or reset on double-click.
- Linked fader changes still use the existing stereo transaction and bus/device guarded requests.

## Offline coverage

```shell
node tests/fader_value_edit_ui_test.cjs
PYTHONPATH=src pytest -q
```

## Physical-device checks

1. Reduce speaker/monitor level before starting. On a DICE/RME device, type `+3.1 dB`
   into a channel volume box and press Enter. Observe the displayed level and test
   actual hardware readback by refreshing the bus.
2. Type `0`, `-0.0`, and `+0.0`; the displayed result must be `0.0 dB`.
3. Double-click the fader track or handle; verify that it returns to 0.0 dB,
   not to the `−∞ dB` silent endpoint.
4. Type an invalid number like `+20 dB` and confirm no change is applied.
5. Repeat on the master output, then select another output and confirm a stale edit
   cannot affect the previous one.
6. Verify a MOTU UltraLite profile without native dB metadata retains 0–100
   display/editing and does not perform a guessed 0 dB reset.
7. Verify stereo-pair and muted-channel behavior on the actual hardware.

These checks cannot be completed without a connected FireWire audio device and browser.
