# Frontend reliability — item 4 (v1.1.1-dev)

This update builds on the **backend-reliability** archive (which includes the
previous audio-safety patch). The frontend changes do not modify the server's
network binding, hardware gain math, or device profiles.

## What changed

- `frontend-api.js` provides consistent JSON/error parsing and FireWire GUID
  tagging for API reads and settings writes, as well as serialized writes for
  the same logical preference/layout and latest-only, abortable **GET** reads.
  **Hardware-changing POSTs are never aborted**: a canceled client request
  would not imply that the FFADO operation was canceled on the server.
- Mixer state, bus layout, output master, device enumeration, and mute-recovery
  reads ignore stale results. Routing-panel refreshes are canceled when a
  different tab is opened or the overlay closes; older responses cannot
  repaint a newer selection.
- Appearance, accent colors, hide-minimized, intro-screen, QjackCtl visibility,
  selected output/bus, and sidebar width saves are checked for server success.
  Failed settings writes display a toast and restore the last confirmed value
  where that value can be safely restored; explicit preference edits announce
  confirmation. Rapid edits to the same setting are serialized.
- Channel and output label renames validate server responses and restore the
  prior displayed label on failure. Layouts are serialized per bus/device and
  resynchronized if the last save failed. A canceled sidebar drag is not saved.
- Until an output-level read completes, the master fader refuses writes and
  its mute button is disabled. If the read fails, the stale master is hidden.
  If a mixer bus read fails, its stale channel strip view is replaced by an
  error instead of remaining usable as if it belonged to the new bus.

## Offline validation

From the project root:

```sh
python -m pytest -q
node tests/frontend_reliability_ui_test.cjs
node tests/frontend_save_ui_test.cjs
for t in tests/*_ui_test.cjs tests/peak_display_test.cjs tests/theme_icons_ui_test.cjs; do node "$t" || exit; done
node --check ffado_webmixer/assets/static/frontend-api.js
node --check ffado_webmixer/assets/static/index.js
node --check ffado_webmixer/assets/static/routing.js
```

## Browser/device checks (actual FFADO hardware required)

1. In Settings, change theme and accent; confirm they persist after restart.
   Disconnect from the server while saving and check for a visible error
   and restoration of the last saved preference. Check the same behavior for
   Show minimized and the loading-screen checkbox.
2. Rapidly switch buses, output masters and routing tabs, while inspecting
   the network panel: a later selection should not display data from an
   earlier selection, even if that earlier request is slow.
3. Change pins and strip order, then reload; verify layout persists for its
   originating bus. Test with two browser tabs open.
4. Rename a channel and output; confirm a rejected request does not leave
   a fake saved label in the interface.
5. Switch between two output masters. The master cannot change the selected
   hardware output until that output's current level has been retrieved.
6. Verify mute/solo and crossbar writes still succeed. These writes MUST NOT
   be canceled when a routing read becomes obsolete or a tab is closed.

There is no physical FireWire, Qt/pywebview, or live mixer test in the offline
review environment. Test with monitoring levels lowered before a live session.
