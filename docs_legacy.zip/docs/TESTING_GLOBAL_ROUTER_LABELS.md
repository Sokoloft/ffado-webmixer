# Crossbar Router / mixer matrix live source-label consistency

Development version: **1.1.1**. Validation on real FireWire hardware is pending.

## Reproduce the disconnected Input 9 case

1. Start ffado-webmixer with a mapped Saffire PRO 40 or other supported DICE interface.
2. Open **In/Out → Crossbar Router**. Set destination `Mixer/In:09` to **Disconnected**. The router should show `In 9 ← Disconnected` and its selector should read **Disconnected**.
3. Switch to **Mixer matrix**. Row 9 should read **Disconnected**, matching the source beneath fader 9. The remaining row order and all existing coefficient values must be unchanged.
4. Return to Crossbar Router and choose `1394/In:01` for `Mixer/In:09`. The router should read `In 9 ← Firewire 1`; matrix row 9 should read **Firewire 1**, as should the fader label.
5. Try `Mic/Lin/In:03` on a device exposing that source; the row/selector/fader should say **Analog 3**.
6. Keep the matrix open in one browser and modify `Mixer/In:09` in another browser. The first should refresh on the routing event, preserving edited mixer volumes.
7. Modify a physical output destination (e.g. `Line/Out:01`): no mixer input label should change.
8. With an arbitrary stereo pair linked (such as Left = 2, Right = 5), confirm its fader uses the two *selected* hardware sources in that order. Matrix rows are still individual sources, not stereo-pair names.
9. Change routing in the original `ffado-mixer`, then click **Refresh** in the matrix tab. The UI should read the actual destination source, not the old discovery-time name.

## API inspection

`GET /api/matrix` contains both `inputs` (fixed, original FFADO matrix identifiers) and `input_labels` (live, same-index router source labels). For a disconnected ninth input, `input_labels[8]` is `"Disconnected"`. Do not send the display label as a routing destination or use it for matrix indexing.

`GET /api/router` keeps `destinations`, `sources`, and `selected` as original FFADO strings. Only the human-facing selector option and destination text are shortened.

## Safety and coverage

No DBus writes occur during label refresh. The simulated regression tests cover Saffire PRO 40, Saffire PRO 26, ProFire 2626, external controller changes, disconnected routes, and untouched non-mixer destinations. MOTU devices without a DICE crossbar retain their existing matrix labels.
