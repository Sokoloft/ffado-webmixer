# FFADO display-name cleanup — v1.1.1 development branch

This change affects **visible names only**, never FFADO D-Bus paths, router/matrix
lookups, saved bus/channel identifiers, or stereo pairing order.

## Saffire PRO 40 display checks

1. Launch the device and check input labels at the bottom of channel strips.
2. Confirm `Mic/Lin/Inst:01` and `Mic/Lin/Inst:02` are shown as **Analog 1** and **Analog 2**.
   On the Saffire PRO 40, inputs 3–8 instead use `Mic/Lin/In:03` through
   `Mic/Lin/In:08`; verify each is shown as **Analog 3** through **Analog 8**.
   Linking inputs 3+4 should show **Analog 3+4** (one category label).
3. Confirm `1394/In:01` is displayed as **Firewire 1**, and a linked
   `1394/In:01+02` as **Firewire 1+2** (not “Firewire 1 + Firewire 2”).
4. On supported devices, repeat with any nonadjacent/reversed pair:
   Left=`1394/In:05`, Right=`1394/In:02` should display **Firewire 5+2**.
5. Check In/Out matrix and bus selectors for existing `In N` and `Bus N`
   labels and make sure hardware routing still works as before.
6. Rename a channel manually (for example, “Vocals”): the custom name
   must not be altered by the formatter.

**Important:** `Mic/Lin/Inst` and `Mic/Lin/In` are presented as “Analog” because
they refer to analog input connectors. The original FFADO identifiers are kept
unchanged. Device-family naming is not inferred from channel index.

## Automated checks

```bash
node tests/pro40_compact_names_ui_test.cjs
python -m pytest -q tests/test_compact_ffado_labels.py
```

This is a presentation-only fix. No FireWire hardware writes are introduced.
