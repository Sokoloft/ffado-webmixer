# Testing intro-screen persistence and theme selection

This v1.1.1 development patch applies over the **global router/matrix labels**
release. Only startup preferences, loading-page styling, and setting-save
feedback were changed. FFADO mixer controls, routing, and device-specific
layouts are unchanged.

## Skip intro regression

1. Start **normal hardware mode** with `python main.py` and open **Settings → General**.
2. Check **Skip loading screen**. Verify it stays checked when reopening Settings.
3. Quit and restart `python main.py` (not `--demo` or `--debug`). The desktop
   should navigate directly to the mixer without waiting on the intro timer.
4. Disable the option and restart. The intro screen should appear again.
5. With two interfaces connected, switch devices and verify the checkbox
   shows the same value. Restart and confirm it has not been reset.
6. Check `~/.config/ffado-webmixer/config.json`: `settings.skip_loading_screen`
   should reflect the most recent checkbox selection. A per-GUID device JSON
   may still contain its older value, but it no longer overrides the startup
   preference.

## Theme regression

1. Disable Skip, select **Light** in **Settings → Theme**, then quit and restart.
   The intro page should have a light background, dark text and a themed logo;
   it should not flash the old dark Qt background.
2. Repeat with **Gruvbox**, **Nordic**, and a custom theme from
   `~/.config/ffado-webmixer/themes/`.
3. Set a custom accent for the selected theme. Restart and verify that the
   intro's indicator, logo accent and scan bar use the override.
4. Verify that opening the mixer still applies the theme and accent normally.
5. If upgrading from an older v1.1.1 checkout with a saved intro preference only
   in a GUID file, the first normal hardware startup migrates it to the global
   config. Subsequent changes to the global checkbox must not be overwritten.

**Important:** `--demo` and `--debug` deliberately use in-memory settings, so
changes in those modes are not persisted. Browser-only `--headless` does not
show a pywebview intro.

## Automated tests

Run `python -m pytest -q` and
`python -m pytest -q tests/test_startup_preferences_and_splash.py`.
The intro theme CSS was also checked via Chromium rendering in the isolated
sandbox; the actual pywebview file-based loading screen needs confirmation
in KDE Plasma with Qt6.
