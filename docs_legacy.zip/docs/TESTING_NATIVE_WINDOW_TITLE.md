# Native pywebview title after device switching

## Change

The native Qt/pywebview window title is now synchronized with the selected
FFADO device after `/api/describe` is loaded. `document.title` by itself
updated only the browser document and did not reliably update the native title.

The frontend calls the existing pywebview Python bridge, which queues the
window update onto the Qt GUI thread. The bridge also handles cases where
`/api/describe` finishes before `pywebviewready` fires. Standalone browsers
are unaffected.

## Physical desktop test (requires multiple connected FFADO devices)

1. Open the desktop app with the MOTU UltraLite selected. Check that the native
   window title includes `ffado-webmixer: MOTU UltraLite`.
2. Use the device selector next to Hardware Routing to select Saffire PRO 40.
   When the mixer reloads, check the native window's **title bar** (or KDE's
   window/task switcher). It should now contain `Saffire PRO 40` without
   quitting and relaunching the application.
3. Switch back to the MOTU. The native window title should return to the MOTU
   name. Repeat to catch timing-dependent failures.
4. Simulate a failed device selection (only if a naturally unavailable device
   is listed). Confirm the title still describes the previously active device.
5. Open the same mixer URL in a regular browser and switch devices there.
   The web page's document title should continue updating without a native
   bridge error.
6. If possible, repeat with **Skip loading screen** both on and off.

No matrix gain, FireWire routing, or audio-stream operations are involved in
this title fix. Automated tests use mocked Qt signals, not real KDE windows.
