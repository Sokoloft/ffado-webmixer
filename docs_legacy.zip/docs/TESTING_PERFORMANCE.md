# Item 5: FFADO read efficiency and responsiveness

This build includes items 1, 2, 4 and 5. Item 3 (network access control) was intentionally skipped.

## Code change

Only `ffado_webmixer/mixer.py` has production-code changes in this item.

During `Mixer.read_mix(..., stereo_bus=True)`, the ordinary fader read already
retrieved the left-bus native coefficient inside the helper's hardware transaction.
The stereo read used to request the identical cell again. That same live value is
now passed to `_matrix_raw(..., actual=raw)` for effective-level/mute handling;
the right leg is still read independently. `_matrix_raw` continues to check
external software-mute overrides and does not keep a long-lived gain cache.

There are no modifications to gain converters, write paths, stereo balance
formulas, router configuration, FFADO peak calibration, frontend throttling,
SSE sampling cadence or FFADO transaction scope.

## Offline benchmark

From the project root:

```sh
python benchmarks/benchmark_responsiveness.py --rpc-ms 1 --iterations 20
python -m pytest -q tests
for file in tests/*.cjs; do node "$file" || exit 1; done
```

The benchmark uses the project debug FFADO devices. `--rpc-ms 1` simulates a
1 ms round-trip on each FFADO matrix read/write or router call. It doesn't
connect to real FireWire, start Flask, send HTTP requests or paint browser frames.
The benchmark measures the Python backend's full mixer snapshot, single-strip
fader writes, and a two-subscriber SSE peak stream using the debug DICE router.

Example measurement on the review environment, 20 iterations at simulated
1 ms/device call (wall clock varies by machine/load):

| Measurement | Before | After |
| --- | ---: | ---: |
| ProFire 2626, 18-channel linked bus: matrix getValue calls/refresh | 54 | 36 |
| ProFire 2626 linked bus refresh average | ~59.3 ms | ~42.2 ms |
| MOTU UltraLite mono bus: getValue calls/refresh | 10 | 10 |
| MOTU UltraLite mono bus refresh average | ~11.1 ms | ~11.1 ms |
| ProFire single-fader write average | ~2.2 ms | ~2.4 ms |
| MOTU single-fader write average | ~1.1 ms | ~1.1 ms |
| Peak stream: getPeakValues per 20 samples, two browser subscribers | 20 | 20 |
| Peak stream: hasPeakMetering per 20 samples | 1 | 1 |
| Peak sample spacing | ~100 ms | ~100 ms |
| Peak sample -> internal subscriber queue delivery, p95 | ~0.4 ms | ~0.4 ms |

The 18 redundant reads removed from every linked bus refresh are a 33.3% drop
in the matrix reads for that request. Latency is a modelled example, not a
promise of a particular reduction on actual FireWire devices. The backend
fader path was **not changed** because the measured write path was already short;
existing ordered/coalesced browser writes remain in place for safety. Two SSE
subscribers share one `getPeakValues` call each tick, not one each, so metering
was not altered either. Queue-delivery times exclude Flask, sockets, browser
layout/painting, and real hardware latencies.

## Manual live-hardware checks (monitoring levels down)

1. With FFADO/JACK running, open a supported DICE/RME linked bus. Confirm the
   fader level, left/right balance, matrix legs, and crossfeed indications match
   the physical settings, including after edits from FFADO's other clients.
2. Mute each leg in the UI and confirm the linked fader continues to show
   effective/saved coefficients, without unexpectedly restoring an input.
3. Check mono buses and the MOTU UltraLite: no change in display or writing.
4. Open two browser clients, enable peak meters and confirm they follow live
   signal without growing latency or getting stuck after a bus/device switch.
5. Drag a fader rapidly, release, and confirm the final hardware value is
   correct. Keep monitoring down during this check.

To measure actual hardware improvements, time repeated `/api/state?mix=0`
requests before/after using the same bus, device, sample rate and JACK load.
Browser Network timings include Flask/HTTP overhead and do not isolate FFADO;
measure D-Bus separately if that distinction matters. Do not use a benchmark
that changes hardware gain continuously on speakers at normal volume.
