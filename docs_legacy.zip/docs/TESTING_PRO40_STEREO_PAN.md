# Saffire PRO 40 — stereo pan and compact labels (v1.1.1-dev)

These steps use **a physical FireWire device**, which the automated tests cannot emulate.

## Before testing

1. Reduce speaker/headphone monitoring volume; an explicit stereo balance adjustment **can activate a previously disconnected diagonal route** if the other diagonal has a level. This is the requested behavior so that pairing an input on the left with a second input on the right actually works. A link/unlink operation alone never changes hardware routing.
2. Take a screenshot/export of **In/Out → Mixer matrix**, especially any existing custom cross-routes. Pan preserves cross-routes; therefore an already existing Right-input → Left-bus route can still make the mix sound more mono than the balance control suggests. The `*` on the balance value indicates that cross-routes also contribute.
3. On DICE/RME mixers, **link Bus 1+2** (or the appropriate adjacent output pair) before using stereo input balance. A linked input alone doesn't create a stereo physical output. Selecting the Right bus now returns to the linked pair's Left bus automatically.

## Pair and pan

1. With Bus 1+2 linked, use the chain-link buttons to pair **Input 2 as Left** and **Input 5 as Right**. Either channel order is supported; first click always means Left.
2. Observe the matrix before touching Pan: the linking operation must not write a single coefficient.
3. Route Input 2 → Bus 1 at an audible, low monitor level. Leave Input 5 → Bus 2 disconnected (−∞). Optionally preserve any custom crosspoint and note its value.
4. Move the linked Pan from left toward **center**. The explicitly requested adjustment should set **both diagonals**: Input 2 → Bus 1 and Input 5 → Bus 2; it must not change Input 2 → Bus 2 or Input 5 → Bus 1.
5. Move Pan to **L100, R100, and center**. Both diagonal routes should behave as an ordered stereo balance and recover the other leg after an end-stop.
6. Confirm that unpaired channels remain independent, including their pan display and hardware coefficients. Repeat with the reversed order (e.g. Input 8 Left, Input 3 Right).
7. Confirm that the slider commits once on release, rather than issuing repeated hardware transactions throughout a drag. Mouse-wheel changes should coalesce.
8. If both diagonal routes are disconnected, Pan should show `—` and not create an output route. Use the matrix editor to establish an initial low-level route.
9. If the bus pair is not linked, the linked input's Pan should explain **Link the output buses as a stereo pair** instead of silently trying nonexistent DICE pan controls.

## Compact names

The UI should show `Mixer/Out:01` as **Bus 1**, `Mixer/In:02` as **In 2**, and `Anlg/In:02` as **Analog 2**. This affects the strip labels, bus selector, and matrix headings. Custom names and real FFADO D-Bus endpoint names are unchanged. Unknown hardware labels are shown verbatim.

## If an issue remains

Include `/api/describe` (`mixes`, `matrix`, and `features`), `/api/state?mix=0` **before and after** moving Pan, a screenshot of the matching 2×2 matrix region, and which output bus is selected. Avoid sharing unrelated device identifiers if unnecessary. The tests are offline software simulations; the hardware's actual routing and audio still need confirmation.
