# Item 6 — cumulative regression and hardware-verification checklist

This release builds on the **item 5 performance build**, which already includes
items **1 (audio safety), 2 (backend reliability), 4 (frontend reliability),
and 5 (read efficiency)**. Item **3 (LAN authentication/binding)** was deliberately
**skipped** and has not been implemented. Item 7 (pip packaging) is not included.

**Scope:** this update adds or extends tests and documentation only. There are
**no production code changes**, gain conversions, profile changes, routing
algorithm changes, meter cadence changes, or new runtime dependencies.

## Run the complete offline suite

From the source tree:

```sh
python -m pytest -q -rs
for file in tests/*.cjs; do node "$file" || exit 1; done
python benchmarks/benchmark_responsiveness.py --rpc-ms 1 --iterations 20
```

The benchmark simulates D-Bus calls, does **not** drive actual FireWire hardware,
and should not be mistaken for a physical latency measurement. The Python
suite tests source-defined *debug* FFADO devices and uses fakes where Flask,
Qt, or D-Bus are unavailable.

### Regression map

| Failure this guards against | Offline test(s) | Physical verification |
| --- | --- | --- |
| Old fader command lands on another bus/GUID or overtakes a newer level | `audio_safety_ui_test.cjs`, `test_multidevice_kde.py` | H1, H2 |
| Crossbar old source is disconnected and new source fails; exceptions/readback failures leave wrong input | `test_audio_safety.py`, `test_router_strip_labels.py` (including an exception **after disconnect**) | H3 |
| Generic stereo-pair write fails after first/second leg changes the device; rollback fails silently | `test_audio_safety.py` (DemoMixer, MOTU, Saffire profiles), `test_stereo_group_mute.py` | H4 |
| Mixed valid/invalid settings accidentally partially persist | `test_backend_reliability.py` | H5 |
| Two browser settings requests interleave global/device settings, or disk save fails after writing | `test_backend_reliability.py` (concurrent calls + rollback) | H5 |
| Invalid layout body or duplicate IDs corrupt the next successful layout | `test_backend_reliability.py` | H6 |
| Occupied port or crashed server leaves the desktop splash waiting indefinitely | `test_backend_reliability.py` | H7 |
| Failed frontend save appears successful or an older failed save undoes a newer edit | `frontend_save_ui_test.cjs`, `regression_failure_recovery_ui_test.cjs` | H5, H6 |
| Out-of-order/canceled read updates the wrong device, bus, or router panel; failed save blocks the next one | `frontend_reliability_ui_test.cjs`, `regression_failure_recovery_ui_test.cjs`, `matrix_cell_rotary_ui_test.cjs` | H1, H2, H6 |
| An optimized stereo bus refresh reuses outdated data or changes mute/readback semantics | `test_performance.py` (fresh snapshot test), `test_soft_mute_recovery.py` | H8 |
| Meter fanout multiplies sampling for multiple browser clients or loses the correct device | `test_peak_stream.py`, `peak_stream_ui_test.cjs`, benchmark | H9 |

Passing this table is **software regression coverage only**. It does not
establish that a specific physical FireWire device supports a control, that a
hardware write is atomic, or that a rollback will succeed on a bus failure.

## Hardware verification (not performed by the offline suite)

**Before any live test:** Back up `~/.config/ffado-webmixer/`; reduce headphone,
monitor, and amplifier levels; disconnect PA/amplifiers if practical; and use a
low-level test signal. Do not intentionally cause FireWire errors by hot
unplugging an interface, especially a bus-powered MOTU UltraLite. Do not run
any of these tests in a live production session.

Use the **MOTU UltraLite mk1** for mono buses, linked input faders and device
selection. Use a **Saffire PRO 40** (or a supported ProFire device) for native
DICE stereo-bus, Crossbar Router and matrix readback checks. Skip a case if
its specific hardware control is not exposed on that model; record the skip
rather than treating an absent feature as a failure.

| ID | Safe manual test | Expected result |
| --- | --- | --- |
| **H1** | On MOTU Bus 1, move a fader and immediately select Bus 2, repeating rapidly in one browser. | Only Bus 1 receives the original movement. Bus 2 remains unchanged. Returning to Bus 1 shows the *final* value. |
| **H2** | With two devices actually connected, issue a low-level fader edit on device A while switching the browser to device B. Check both devices individually. | Delayed writes keep the original GUID; device B is not accidentally modified. If only one device is available, mark as not tested. |
| **H3** | On the PRO 40, use valid Crossbar Router source changes, including a source to Disconnected and back; refresh routing afterwards. | Readback and UI labels agree. Other destinations do not change. **Do not induce a bus timeout to test rollback**; that scenario is simulated offline. |
| **H4** | Link two MOTU channels, gently adjust the shared fader, switch buses, then unlink. Repeat on a DICE device only for supported pair controls. | Both linked legs follow the change, unrelated buses do not, and unlinked channels recover their independent states. Actual hardware timeout recovery remains unverified. |
| **H5** | Change theme, accent and show-minimized settings, restart the app, then try an invalid API payload or a save while the server is intentionally unreachable. | Successful changes persist; rejected ones produce visible errors and do not change saved settings. Any preview returns to the confirmed value rather than pretending it was saved. |
| **H6** | Reorder/minimize strips on two buses, save, switch rapidly, then reload; include a second browser tab if possible. | Each bus keeps its own layout, canceled/stale reads do not replace the selected bus, and hidden channels retain their settings. |
| **H7** | Start a dummy process listening on port 5000, then run `python main.py --demo`. Stop the dummy process afterward. | Startup reports a bind error instead of showing a never-ending splash; normal startup works again when the port is free. No real mixer is required. |
| **H8** | With a DICE stereo bus open, change a matrix level through a second FFADO controller, then refresh webmixer. Check left/right balance and software mute status. | Fresh hardware value is displayed; no stale caching, unexpected unmute, gain-scale shift or routing change. On MOTU, check an ordinary mono bus refresh. |
| **H9** | Open webmixer in two browser clients with meters enabled; switch buses and devices while passing a low-level signal. | Meters follow the correct channels without sustained stalls or device bleed. Their display behaves similarly with one and two clients. |

For H7 on Linux, one way to reserve the port for the test is:

```sh
python -m http.server 5000 --bind 127.0.0.1
# in another terminal: python main.py --demo
# stop http.server with Ctrl+C when finished
```

### Actual hardware response times

For consistent timings, compare requests on the **same** device, bus, JACK
sample rate, JACK buffer, network path, and number of browser clients.
Use the browser's Network panel to time `GET /api/state?mix=0`. If you need to
isolate FFADO from Flask/HTTP and browser rendering, instrument hardware D-Bus
reads separately. The supplied benchmark deliberately does not claim to
measure real FireWire latency or browser paint timing. Avoid loops writing to
hardware faders at normal speaker volume.

## Validation limits and signoff

- **Offline:** Python tests, Node tests, optional static compile/XML validation,
  and simulated benchmark. These can be completed without audio hardware.
- **Unverified here:** physical FireWire routing/readback after errors, analog
  monitor levels, multi-device behavior on real hardware, peak-stream timing
  over your LAN, Qt/pywebview startup and Flask HTTP with real dependencies.
- **Best-effort rollback:** A hardware write that changes the device and then
  times out is not an atomic FireWire transaction. If the app warns
  `rollback may be incomplete`, stop relying on cached UI values, lower
  monitoring, and inspect actual hardware routing/levels before resuming.
- **Skipped dependency-bound tests:** the three Flask tests run only in an
  environment with Flask installed; the FFADO-source citation check requires
  `FFADO_SOURCE_DIR`. The exact skips should be inspected via `pytest -rs`.

Suggested signoff record: hardware model/firmware, OS/kernel, libffado version,
JACK sample rate/buffer, browser, wired/Wi-Fi, which H1–H9 cases passed,
failed or were skipped, and any console/D-Bus errors. Keep this record with
the release before using it at a live show.
