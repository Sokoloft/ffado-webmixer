# Remember last selected mixer — verification

This update saves the **FireWire GUID** of the last selected mixer to the main
`~/.config/ffado-webmixer/config.json`, under `settings.last_device_guid`.
Individual mixer layouts, names, and settings remain in the existing per-GUID
files. The selected GUID is only saved when a device switch succeeds.

## On physical hardware (Saffire PRO 40 + MOTU UltraLite)

1. Connect both devices and launch the desktop application.
2. Select the Saffire PRO 40 from the device dropdown and close the app normally.
3. Open the application again. The selected mixer, its browser page and the
   native pywebview window title should all reflect the Saffire PRO 40.
4. Switch to the MOTU UltraLite, close, and reopen. It should load the MOTU.
5. Close the app; disconnect the selected device **only after safely powering
   down the FireWire setup**. Start with only the other device present. The
   available mixer should load instead of an error or blank screen.
6. Reconnect the preferred device safely and restart the app. The previously
   saved selection should be restored (unless you selected a different device
   in the meantime).
7. With two separate browser profiles, verify that switching one browser
   does not silently redirect the other browser's currently selected mixer.
   A *new* session defaults to the most recently selected device.

## Offline regression cases

`PYTHONPATH=src python -m pytest -q tests/test_multidevice_kde.py`

Covers restart persistence, discovery-order changes, unavailable devices,
independent browser-session selection, malformed preferences, simulated disk
write errors (including failure after file replacement), and in-memory-only
demo preferences. No real FireWire device, D-Bus service, or pywebview is
required to run these tests.

Actual device discovery, native window-title timing, and hardware switching
must still be confirmed on a computer with supported FFADO hardware.
