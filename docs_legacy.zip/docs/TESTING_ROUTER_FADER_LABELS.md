# Crossbar Router → channel-strip source labels (v1.1.1 development)

The hardware input name shown at the **bottom** of each DICE mixer strip should describe the **current Crossbar Router source feeding that mixer input**, not a name copied from matrix discovery at program startup.

## Saffire PRO 40 / ProFire hardware checklist

1. Start with a safe monitor level. Open **In/Out → Crossbar Router** and locate a destination such as `Mixer/In:01`. Do not use `Line/Out:01` for this test; line-output routing is a different signal path.
2. Note the selected source, e.g. `Mic/Lin/Inst:01`. Beneath the corresponding channel strip, the hardware-input label should show the compact form such as **Analog 1**.
3. Reassign `Mixer/In:01` to an available `1394/In:01`, `SPDIF/In:01`, or other valid source. The label should change immediately to **Firewire 1**, **SPDIF 1**, etc., without changing matrix faders or reloading the browser.
4. If both inputs of a linked pair are changed to `1394/In:01` and `1394/In:02`, the combined strip should show **Firewire 1+2**, retaining the original Left/Right pairing order. Other buses' pairs and names must remain unchanged.
5. Set the destination to **Disconnected**. The bottom strip label should say **Disconnected**. Restore the connection and verify its source label returns.
6. Test in a second browser or device: change the router in the first browser; the other viewer should update from the SSE `routing` event.
7. Change a **physical output** destination, e.g. `Line/Out:01`. This must **not** rename a mixer input strip or change its fader gain.
8. If you've explicitly renamed a strip (its editable top name), that user-chosen name should remain; only its non-editable hardware-source label changes.
9. If routing is changed using another program such as ffado-mixer, open or refresh the Crossbar Router page: reading the hardware snapshot should update strip labels. A background crossbar poll is intentionally **not** added, to avoid extra FireWire D-Bus reads.

## Diagnostic data

Compare these URLs **before and after** changing `Mixer/In:01`:

- `/api/router` → `selected["Mixer/In:01"]`: actual FFADO router source.
- `/api/state?mix=0` → `"ch/00".input`: source displayed below the first fader.

The two names should agree after hardware readback (before the browser's compact label formatting). The stored FFADO matrix column name is not renamed; channel IDs and gain coefficients must stay unchanged.

These operations have offline regression coverage on Saffire PRO 40, Saffire PRO 26 and ProFire 2626 debug fixtures. Live audio routing and UI responses remain to be verified on physical hardware.
