# Stereo FireWire playback — Saffire PRO 40 (v1.1.1-dev)

The PRO 40 manual (pp. 10–11, 13–17) distinguishes the computer's **DAW output channels** from the hardware **mixer inputs**, **mixer output buses**, and **physical line outputs**. DAW 1 and 2 are two independent mono streams; the MixControl stereo-track UI pairs them for convenience. FFADO's underlying mixer matrix still exposes four separate crosspoints.

## What this version adds

**In / Out → Mixer matrix → Stereo FireWire playback** offers a one-click *explicit* stereo patch when the FFADO EAP Crossbar Router already assigns both `1394/In:01` and `1394/In:02` to two distinct `Mixer/In` destinations. It also supports other odd/even playback pairs if FFADO reports them. The list is built from live FFADO source and destination names, **not hardcoded matrix columns**.

For FireWire 1 Left, FireWire 2 Right, and Bus 1+2:

| Matrix crosspoint | New value |
|---|---|
| Firewire 1 → Bus 1 | 0 dB |
| Firewire 2 → Bus 2 | 0 dB |
| Firewire 1 → Bus 2 | −∞ |
| Firewire 2 → Bus 1 | −∞ |

All other mixer crosspoints and Crossbar Router connections are preserved. The action requires explicit confirmation, verifies the matrix-cell readback, and attempts to restore all four previous coefficients if a write fails. It is not triggered by simply linking input strips or buses.

## Before you apply

1. **Turn speaker/headphone volume down.** Setting a mixer path to unity may be substantially louder than the prior routing.
2. Ensure JACK/PulseAudio sends left playback into the device's FireWire playback 1 and right into 2. JACK port names or ALSA indices are not necessarily the same as Crossbar Router destination labels; check actual signal activity if unsure.
3. Open **In / Out → Crossbar Router**. Assign `Firewire 1` to a mixer-input destination and `Firewire 2` to a *different* mixer-input destination. These may be Input 5 and Input 9 rather than 1 and 2; the helper follows real assignments. If either source is absent or assigned to multiple mixer inputs, the pair will not be offered because choosing a specific fader would be ambiguous.
4. Confirm the physical outputs you listen to are routed as intended. For example, assigning `Mixer/Out:01` and `Mixer/Out:02` to the two physical monitor destinations is **separate** from the mixer patch described here. Do not leave a direct FireWire or analog bypass to the same physical output when evaluating mixer controls.
5. Note that **linked input faders** and **linked output buses** remain UI groupings. Link Bus 1+2 for integrated stereo balance controls after applying the route; link the two actual faders if you want them represented as one stereo input strip. The first clicked channel is Left, even when its input number is higher.

## Test on hardware

1. Before the patch, play a stereo test source with speech only on Left, then only on Right. Write down which output is audible and record the four affected matrix levels.
2. Open Mixer matrix, choose **Firewire 1+2** and **Bus 1+2**, and click **Route L/R**. Confirm the warning after lowering monitoring volume.
3. Check the four target matrix cells: the diagonal must read 0 dB, and the two crosspoints must read −∞ dB. All unrelated rows/columns must retain their previous values.
4. With the physical monitor output router selecting Mixer Out 1 (Left) and Mixer Out 2 (Right), left-only test audio should appear exclusively on the Left speaker; right-only audio exclusively on the Right.
5. Verify that a failed write results in a visible error and the original four levels being restored; this has only been simulated offline and must not be induced on production hardware without care.
6. Repeat using a pair on different mixer input columns (for example Mixer Inputs 5 and 9). The helper must not assume matrix Inputs 1 and 2.

## Limitations

- This is **not** a FireWire driver change and does not remap JACK audio ports. It patches the internal monitoring mixer *after* the device receives the stereo streams.
- The feature appears only on supported source-mapped DICE EAP devices where the pair has unique live Crossbar assignments. It does not guess the routing for an unsupported interface.
- It does not automatically change physical output routing, enable/disable stereo bus links, or create channel pairs.
- At 88.2/96 kHz the number of available device channels can differ. Available options are determined from the current FFADO hardware inventory rather than from manual defaults.
- Physical PRO 40 verification is pending. Existing tests are offline D-Bus fixtures only.
