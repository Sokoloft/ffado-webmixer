# Live peak stream / smooth metering — v1.1.1-dev

This update is based on the **architecture** (not copied source code) of the
supplied `ffado-web-mixer-main.zip` reference: a single background FFADO meter
read about every 100 ms is pushed to connected clients. That project uses
`aiohttp` WebSockets; ffado-webmixer retains Flask and uses **Server-Sent
Events** instead, requiring no new application dependencies.

## What changed

- `/api/peak-stream` provides live JSON SSE updates, keyed by the active
  device's real FireWire GUID; `/api/peaks` remains unchanged for diagnostics
  and as a client fallback.
- One on-demand sampler per connected device feeds all viewers, making exactly
  one `getPeakValues()` call per cadence independent of the number of viewers.
- Slow clients receive the **newest** snapshot in a one-frame queue; missed
  values are dropped rather than being displayed seconds late. The sampler
  sleeps only the remainder of its 100 ms cadence, not another 100 ms after a
  slow D-Bus read.
- Closing the last viewer stops that device's sampler. Background/hidden browser
  tabs unsubscribe; visible tabs resume. Server errors don't invent peaks.
- Each strip reuses DOM nodes for the lifetime of the strip element. The meter
  gradient stays fixed to its full range, with a short ~80 ms transition
  between samples and independently held peak/near-full-scale markers.
- Multi-device GUID checks, genuine router-destination mapping, separate
  L/R lanes, click-to-clear holds and the Crossbar Router meter view are kept.

## Live hardware checks

1. Restart the updated application, and open a supported DICE device (such as
   the Saffire PRO 26/40 or ProFire 2626). Start a clean test signal at low
   monitoring volume. Check that the vertical fader meters react promptly and
   fall smoothly, without delayed multi-second jumps.
2. Open **In/Out → Crossbar Router** and confirm the same known metered router
   destination responds, and yellow/red remain only near the very top.
3. Link nonadjacent inputs (e.g. channel 2 Left + channel 5 Right). Feed only
   one input, verify that ONLY its lane moves, and switch bus tabs.
4. Open the same selected mixer on a phone and desktop at once. Meter
   responsiveness should not slow down as viewers are added. Both pages should
   use the same FFADO sampling thread, not duplicate D-Bus reads.
5. Switch between two physical FFADO devices in separate browser sessions;
   confirm no levels appear on the wrong GUID.
6. Hide the browser tab, bring it back, and confirm metering resumes. On
   failure, open the browser network inspector to verify that
   `/api/peak-stream` returns `text/event-stream`. Older browsers/deployments
   should fall back to `/api/peaks` automatically.

## Read-only diagnostics

`curl -N http://127.0.0.1:5000/api/peak-stream` shows live SSE frames.
`curl -s http://127.0.0.1:5000/api/peaks | python -m json.tool`
remains useful for a single snapshot. This diagnostic curl stream subscribes
as an additional viewer: press Ctrl+C to stop it.

The measurements are normalized FFADO DICE router-destination readings, **not
calibrated post-fader dBFS**. Unsupported devices (such as the first-generation
MOTU UltraLite) remain unmetered rather than receiving guessed data. No
routing, fader, mute, or FireWire audio stream settings are changed.

## Test coverage and limitations

- Shared sampler fanout, bounded queues, concurrent device GUIDs, hardware
  slowness, hardware-error recovery and idle stop are covered with simulated
  FFADO backends.
- Browser tests cover the live EventSource path, JSON fallback, tab visibility,
  stale frames and GUID mismatch. Existing Saffire/ProFire model fixtures and
  CSS pixel color tests still pass.
- The optional Flask streaming integration test only runs in environments
  with Flask installed; this isolated build environment lacks Flask.
- **Live FireWire latency and smoothness are not yet measured on actual
  hardware.** Slow or blocking D-Bus calls can still limit sample cadence;
  push transport removes request-by-request network round trips but cannot
  accelerate the FFADO device itself.
