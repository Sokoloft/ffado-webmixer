# Stereo-bus faders from −∞ — v1.1.1-dev

This fixes the no-op when both DICE stereo mixer coefficients are at their native silent value (0–16). The regression suite uses a simulated FFADO backend, so the behavior still needs physical FireWire validation.

## On the Saffire PRO 40

1. **Turn down speaker and headphone volume first.** Raising a formerly silent fader can make an input audible.
2. In **In / Out → Mixer matrix**, find an unused analog input whose Bus 1 and Bus 2 coefficients are both at −∞. Record any other bus settings before the test.
3. Link **Bus 1+2**. Linking itself must not change either coefficient.
4. Select Bus 1+2 and raise the mono input's volume fader from −∞ to a modest level. Both the Bus 1 and Bus 2 coefficients for that input should become finite, equal, and centered. Other channels and buses remain unchanged.
5. Pan the mono input left, then lower its fader to −∞ and raise it again. The previous Left/Right level ratio should return within this running session. A matrix edit made while the fader is at −∞ should override that memory.
6. Prepare inputs 2 and 5 with all four Bus 1/2 crosspoints at −∞. Pair Input 2 first (**Left**), then Input 5 (**Right**). Linking alone must leave the matrix unchanged.
7. Raise the linked input strip fader. Only Input 2→Bus 1 and Input 5→Bus 2 should be made active. Both cross-routes must stay at −∞.
8. Lower that fader to −∞, then raise it again. The same diagonal routing must recover. Verify that stereo balance becomes available after the input gains become active.
9. Repeat with reversed pairing order, e.g. Input 5 Left, Input 2 Right. Click order must still determine the two diagonals.
10. Verify that a channel with just one existing mono route retains that route without turning on the other bus. Moving a linked bus fader must not alter any unrelated matrix cell, physical output routing, or other device.

Linking buses or faders is always a UI-only action. **The fader raise itself** intentionally connects the selected previously silent input into the selected stereo bus. Do not perform these tests at full speaker volume.

If both bus coefficients become active but the physical Left/Right outputs sound wrong, inspect the **Crossbar Router** separately; physical monitor outputs must receive the intended `Mixer/Out` channels rather than a direct hardware bypass.
