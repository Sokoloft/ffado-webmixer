# v1.1.1-dev — Saffire PRO 40 and ProFire stereo-mute verification

This patch corrects **software mute in the FFADO EAP mixer matrix**. It does not
add hardware mute registers to the DICE matrix or mute direct Crossbar Router
connections. It targets the Focusrite **Saffire PRO 40** (including supported
40.1 variants) and other profile-mapped DICE devices such as M-Audio ProFire
2626/610. It also preserves native-mute devices such as MOTU.

## Before starting — audio safety

Turn down monitors and headphones before testing. An unmute or recovery action
can restore the previous digital mixer level. Disconnect sensitive loads if
needed. **Do not test mute as an emergency safety control** until you've
confirmed exactly which audio paths it affects.

## What changed

- A mono strip on an unlinked bus mutes one DICE EAP MatrixMixer crosspoint.
- A linked *input pair* on an unlinked bus mutes both input crosspoints.
- One strip on a linked *output bus* mutes that input on both output buses.
- A linked input pair on a linked output bus mutes all **four** crosspoints.
- Unmute restores the saved native coefficients without creating cross-routes.
- A partial old mute is indicated by a dashed Mute button; pressing it mutes
  every remaining leg before a later unmute restores them.
- Initial matrix silence (−∞) is no longer labeled as a user-initiated mute.
- Native DICE/RME coefficient values `0..16` are all treated as the hardware's
  silence sentinel for mute/recovery verification.
- Hardware write failures produce an error, refresh UI state, and attempt to
  restore all affected cells with their crash journal intact.
- Existing Solo suppression remains active when its unrelated user mute is
  cleared. The recovery journal must continue to hold solo-suppressed levels.

## Physical Saffire PRO 40 steps

1. Restart `ffado-webmixer` after installing the patch. Confirm that the
   profile is **Saffire PRO 40** and not a similarly named identity-only model.
2. In **In / Out → Mixer matrix**, note the coefficients for a test input on
   `Mixer/Out:01` and `Mixer/Out:02`; capture a screenshot or export values
   before making changes.
3. Select Bus 1. With buses unlinked, mute that input. Confirm that the bus 1
   coefficient becomes `−∞ dB`, while the bus 2 coefficient is untouched.
4. Unmute. Confirm the original numeric value returns (including fractional dB).
5. Link output **Buses 1+2**, then mute a single input. Both bus 1 and bus 2
   matrix legs must become `−∞ dB`. Unmute and verify both original values.
6. With buses still linked, link **Input 2** as Left with **Input 5** as Right.
   Mute their combined strip. All four routes `(2→Out1, 2→Out2, 5→Out1,
   5→Out2)` must become `−∞ dB`, including any custom cross-routes.
7. Unmute. Verify all four crosspoints are restored **exactly to the values
   they had before muting**, with previously disconnected routes still off.
8. Repeat with Bus 2 selected alone and with a single linked input pair. The
   mute must not affect an unrelated output bus.
9. Try muting a single channel before linking it with another, then use the
   linked strip: the UI should mark a partial mute and allow you to finish
   muting both sides. Confirm no silent failures or misleading Mute colors.
10. Check output/master Mute where your Saffire exposes
    `/EAP/Monitoring/LineOut/Mute{n}`: hardware rejected writes must show an
    error toast and refresh readback instead of pretending they succeeded.

## Diagnosing a mute that changes the UI but not the sound

DICE EAP's MatrixMixer is **not** the same control as the Crossbar Router or
Saffire's dedicated hardware LineOut monitoring mute.

If muting changes the `Mixer/Out` matrix crosspoints to `−∞ dB` but the signal
is still audible, open **In/Out → Crossbar Router** and inspect the physical
output's selected source. A direct route such as `Anlg/In:01 → Line/Out:01`
bypasses the software mixer. A `Mixer/Out` source must be routed to that
physical output for the matrix's software mute to affect its audio.

You can also inspect the API (when running on the same machine):

```bash
curl -s http://127.0.0.1:5000/api/state?mix=0 | python -m json.tool
curl -s http://127.0.0.1:5000/api/matrix | python -m json.tool
curl -s http://127.0.0.1:5000/api/router | python -m json.tool
```

Look for `mute`, `mute_partial`, and the relevant `values`/`db_values`. If a
write is rejected, preserve the terminal log and any **Mute recovery** banner.
Do **not** delete `~/.config/ffado-webmixer/devices/*.mute-recovery.json` to
fix it: that file protects the original matrix levels.

## Automated coverage and limitations

Run `python -m pytest -q` and `node --check ffado_webmixer/assets/static/index.js`.
The automated tests use source-derived device profiles and a simulated D-Bus
backend to check 2×2 route selection, native-silence readback, user-mute/Solo
interaction, cross-route preservation, rollback, and error visibility. They
**do not** confirm that actual FireWire hardware passes through the matrix
rather than a direct router path; a real Saffire/ProFire test is required.
