# Stereo bus tabs and channel menus (v1.1.1-dev)

This revision is based on the preceding compact-bus-tabs build. It changes **UI
controls and saved bus-pair aliases**, not FFADO mixer gain/pan computations.

## Bus tabs (nine or more buses)

- With an unlinked pair 1/2, open the ⋮ menu on **either** bus: `Link bus 1+2`.
  Pair 2/3 must never be offered. Pair 3/4 is supported. The last bus of an
  odd-sized mixer cannot be linked if it has no corresponding partner.
- Link: two tabs become one tab, displaying `<name 1>+<name 2>` until renamed.
  The original two FFADO bus identifiers still exist, and the existing stereo
  matrix behavior is unchanged.
- Right-click (or long-press) the linked tab name, type a custom label and
  press Enter. Restart the app: the custom label should still be present.
- Open ⋮ on the linked tab and choose Unlink. The single merged tab splits into
  two independent tabs and the *pair alias* is removed. Individual bus names
  from before linking remain intact; they are not overwritten by a pair alias.
- Re-linking should start with the combined names again (not the old pair alias).
- Pin/minimize the merged tab, close/relaunch and verify state. Pair drag order
  remains contiguous. With the hide-minimized-buses preference selected, the
  active minimized bus must remain accessible.
- Check mobile width and switch themes. Bus tab text must be centered and
  action menus must open outside the horizontally scrollable strip.

## Fader three-dot menu (all channel strips)

- On any mono strip, ⋮ offers Link as Left channel, Pin/Unpin, and
  Minimize/Restore. Select Left; the strip highlights. On another strip's ⋮
  select Link as Right channel. The backend still handles the pair exactly as
  before (including non-adjacent channel IDs and per-bus scope).
- On a paired strip, ⋮ offers Unlink stereo channels. Unlink and verify that
  the two independent channel strips return. If either link operation fails,
  the UI should display the error and refresh its state.
- Minimize a channel, then use its still-visible ⋮ to Restore it. Pin and unpin
  and confirm the setting persists across mixer refreshes. The master fader is
  deliberately unchanged (it has no channel-pair link operation).
- On a narrow phone/tablet view, verify tapping ⋮ opens the menu and does not
  start dragging or alter mixer gain.

## Automated checks

```
PYTHONPATH=src python -m pytest -q tests
for f in tests/*_ui_test.cjs; do node "$f" || break; done
```

New backend fault-injection tests cover linked tab name persistence, invalid
pair indices and names, and rollback of failed link/rename saves. Browser
smoke tests exercised link/rename/unlink and fader-menu operations in headless
Chromium against a simulated 18-bus mixer, not a physical device.

## Physical FFADO checks (still outstanding)

On the Saffire PRO 40, start with low monitoring levels and verify that linking
and unlinking consecutive output buses changes stereo balance as before. Check
that a paired input's mute/solo/pan and fader still control the intended mixer
bus only. Also verify that the single-tab design does not interfere with
FFADO mixer routing, channel input linking, or a selected bus after rapid tab
changes. Repeat any relevant layout checks on the MOTU UltraLite. These checks
cannot be conclusively completed with mock D-Bus responses.
