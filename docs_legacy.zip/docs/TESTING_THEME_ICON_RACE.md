# Concurrent theme-icon cache — v1.1.1-dev

## Reproduction and verification

1. Launch the Qt6 desktop application and open **Settings → Theme**.
2. Switch repeatedly between Dark, Breeze, Catppuccin and Everforest, and change or reset the accent override while switching.
3. Check the native Qt window/taskbar icon and the browser favicon continue to update; the terminal should not print `FileNotFoundError` referring to `~/.cache/ffado-webmixer/icons/*.tmp`.
4. Restart the application and repeat. If Plasma keeps a previously pinned launcher icon until a restart/repin, that KDE cache behavior is independent of the error fixed here.
5. Run `python -m pytest -q tests/test_theme_icons.py` to exercise simultaneous same-theme requests and an interrupted icon-cache write.

The final SVG icon filename is derived from icon content. Temporary filenames are unique per operation and atomically moved into place. Only themed icon caching is changed; hardware mixer state is unaffected.
